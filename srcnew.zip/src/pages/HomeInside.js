import React from 'react';
import { Link } from 'react-router-dom';

const HomeInside = ({ userName }) => {
  return (
    <div className="container mt-5">
      <h3 className="text-center mb-4">Welcome, {userName}! 🌟</h3>

      <div className="text-center mb-4">
        <Link to="/books" className="btn btn-primary">📖 Browse Books</Link>
      </div>

      <h5 className="mb-3">📚 Featured Books</h5>
      <div className="row">
        {/* Book 1 */}
        <div className="col-md-3">
          <div className="card shadow-sm mb-4">
            <img src="https://images.unsplash.com/photo-1528207776546-365bb710ee93" className="card-img-top" alt="Book 1" />
            <div className="card-body">
              <h6 className="card-title">The Silent Library</h6>
              <p className="card-text">Mystery & suspense in a hidden archive...</p>
            </div>
          </div>
        </div>

        {/* Book 2 */}
        <div className="col-md-3">
          <div className="card shadow-sm mb-4">
            <img src="https://images.unsplash.com/photo-1512820790803-83ca734da794" className="card-img-top" alt="Book 2" />
            <div className="card-body">
              <h6 className="card-title">Whispers of Time</h6>
              <p className="card-text">Travel through history with powerful tales...</p>
            </div>
          </div>
        </div>

        {/* Book 3 */}
        <div className="col-md-3">
          <div className="card shadow-sm mb-4">
            <img src="https://images.unsplash.com/photo-1519682577862-22b62b24e493" className="card-img-top" alt="Book 3" />
            <div className="card-body">
              <h6 className="card-title">Code of Shadows</h6>
              <p className="card-text">Tech thrillers and secrets unfold here...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeInside;
