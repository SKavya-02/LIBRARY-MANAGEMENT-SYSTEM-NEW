import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';



const AdminLoginPage = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: ''
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    try {
      const res = await axios.post('https://localhost:7093/api/Admin/login', formData);
      const { token } = res.data;

      localStorage.setItem('adminToken', token);  // ✅ Save admin token only
      setMessage('✅ Admin logged in successfully!');
      console.log('Admin JWT Token:', token);

      navigate('/adminpanel'); // ✅ Admin goes to AdminPanel
    } catch (error) {
      const backendData = error.response?.data;
      setMessage(backendData || '❌ Login failed. Please try again.');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Admin Login 🔐</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm">
        <div className="mb-3">
          <label>Full Name</label>
          <input type="text" name="fullName" className="form-control" value={formData.fullName} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Email</label>
          <input type="email" name="email" className="form-control" value={formData.email} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input type="password" name="password" className="form-control" value={formData.password} onChange={handleChange} required />
        </div>
        <button type="submit" className="btn btn-dark w-100">Login</button>
        <p className="mt-3 text-center">
          New admin? <a href="/admin/register">Register here</a> | <a href="#">Forgot Password?</a>
        </p>
      </form>
    </div>
  );
};

export default AdminLoginPage;
