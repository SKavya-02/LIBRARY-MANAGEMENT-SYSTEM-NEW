// src/pages/Dashboard.jsx
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Dashboard.css"; // 💎 CSS with glassmorphism

const Dashboard = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState({ author: "", language: "" });
  const [isLoading, setIsLoading] = useState(false);
  const [books, setBooks] = useState([]);

  const fetchBooks = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get("https://localhost:7093/api/Book/all", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("userToken")}`,
        },
      });
      setBooks(response.data || []);
    } catch (error) {
      console.error("Error fetching books:", error);
      setBooks([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const filteredBooks = books.filter((book) => {
    return (
      book.title?.toLowerCase().includes(search.toLowerCase()) &&
      (filter.author === "" || book.author === filter.author) &&
      (filter.language === "" || book.language === filter.language)
    );
  });

  return (
    <div className="dashboard-container">
      <div className="container-fluid py-4">

        {/* Dashboard Title */}
        <div className="row mb-4">
          <div className="col-12">
            <h2 className="dashboard-title mb-3">
              <i className="bi bi-book me-2"></i> <center>Library Book Catalogue</center>
            </h2>
          </div>
        </div>

        {/* 🔍 Sticky Glassmorphism Search/Filter Panel */}
        <div className="search-panel mb-4">
          <input
            type="text"
            placeholder="Search by book title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            value={filter.author}
            onChange={(e) => setFilter({ ...filter, author: e.target.value })}
          >
            <option value="">All Authors</option>
            {[...new Set(books.map((b) => b.author))].map((author, i) => (
              <option key={i} value={author}>
                {author}
              </option>
            ))}
          </select>

          <select
            value={filter.language}
            onChange={(e) => setFilter({ ...filter, language: e.target.value })}
          >
            <option value="">All Languages</option>
            {[...new Set(books.map((b) => b.language))].map((lang, i) => (
              <option key={i} value={lang}>
                {lang}
              </option>
            ))}
          </select>

          <button onClick={() => setFilter({ author: "", language: "" })}>
            <i className="bi bi-arrow-counterclockwise me-1"></i> Reset
          </button>
        </div>

        {/* 📚 Book Cards */}
        {isLoading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-light" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : (
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            {filteredBooks.map((book, i) => (
              <div className="col animate-card" key={book.id || i}>
                <div className="card book-card h-100">
                  <img
                    src="https://dummyimage.com/200x300/cccccc/000000&text=Book+Cover"
                    className="card-img-top"
                    alt={book.title}
                  />
                  <div className="card-body d-flex flex-column">
                    <h5 className="card-title">{book.title}</h5>
                    <p className="card-text text-muted">
                      <i className="bi bi-person me-1"></i>
                      {book.author}
                    </p>
                    <p className="card-text">
                      <i className="bi bi-globe me-1"></i>
                      {book.language}
                    </p>
                    <div className="mt-auto">
                      <Link
                        to={`/books/${book.bookId}`}
                        className="btn btn-gradient w-100"
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {filteredBooks.length === 0 && !isLoading && (
              <div className="col-12 text-center text-light py-5">
                No books found 📭
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
