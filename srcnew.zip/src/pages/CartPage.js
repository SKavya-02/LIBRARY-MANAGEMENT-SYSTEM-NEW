import React from 'react';

const CartPage = () => {
  // Dummy for now
  return (
    <div className="container mt-4">
      <h2>🛒 My Cart</h2>
      <p>You have no books in your cart yet. Start adding your favorites!</p>
    </div>
  );
};

export default CartPage;
