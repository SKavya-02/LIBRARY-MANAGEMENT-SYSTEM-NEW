import React from 'react';

const LikesPage = () => {
  return (
    <div className="container mt-4">
      <h2>❤️ Liked Books</h2>
      <p>You haven’t liked any books yet. Start browsing and liking!</p>
    </div>
  );
};

export default LikesPage;
