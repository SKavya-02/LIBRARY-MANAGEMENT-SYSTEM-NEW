import React, { useState } from 'react';
import axios from 'axios';
import "./RegisterPage.css"; // 💖 add this CSS

const RegisterPage = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    gender: '',
    phone: '',
    address: '',
    profilePicture: ''
  });

  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setErrors({});

    try {
      const res = await axios.post('https://localhost:7093/api/User/register', formData);
      setMessage(res.data);
      setFormData({
        fullName: '',
        email: '',
        password: '',
        gender: '',
        phone: '',
        address: '',
        profilePicture: ''
      });
    } catch (error) {
      const backendData = error.response?.data;
      if (backendData?.errors) {
        setErrors(backendData.errors);
      } else if (backendData?.title) {
        setMessage(backendData.title);
      } else {
        setMessage('Registration failed. Please try again.');
      }
    }
  };

  return (
    <div className="register-wrapper">
      <div className="register-container">
        <h2 className="mb-4 text-center title-text">Register 📝</h2>
        {message && <div className="alert alert-info">{message}</div>}

        <form onSubmit={handleSubmit}>
          {/* Full Name */}
          <div className="mb-3">
            <label>Full Name</label>
            <input type="text" name="fullName" className="form-control styled-input" value={formData.fullName} onChange={handleChange} required />
            {errors.FullName && <small className="text-danger">{errors.FullName}</small>}
          </div>

          {/* Email */}
          <div className="mb-3">
            <label>Email</label>
            <input type="email" name="email" className="form-control styled-input" value={formData.email} onChange={handleChange} required />
            {errors.Email && <small className="text-danger">{errors.Email}</small>}
          </div>

          {/* Password */}
          <div className="mb-3">
            <label>Password</label>
            <input type="password" name="password" className="form-control styled-input" value={formData.password} onChange={handleChange} required />
            {errors.Password && <small className="text-danger">{errors.Password}</small>}
          </div>

          {/* Gender */}
          <div className="mb-3">
            <label>Gender</label>
            <select name="gender" className="form-select styled-input" value={formData.gender} onChange={handleChange} required>
              <option value="">Select Gender</option>
              <option value="Female">Female</option>
              <option value="Male">Male</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Phone */}
          <div className="mb-3">
            <label>Phone</label>
            <input type="text" name="phone" className="form-control styled-input" value={formData.phone} onChange={handleChange} required />
          </div>

          {/* Address */}
          <div className="mb-3">
            <label>Address</label>
            <textarea name="address" className="form-control styled-input" value={formData.address} onChange={handleChange} required />
          </div>

          <button type="submit" className="btn register-btn w-100">✨ Register ✨</button>
          <p className="mt-3 text-center">
            Already registered? <a href="/" className="link-text">Login here</a>
          </p>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;
