import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import './AddBook.css';

const AddBook = () => {
  const [form, setForm] = useState({
    id: 0, // include id for edit
    title: "",
    author: "",
    isbn: "",
    publisher: "",
    publicationDate: "",
    edition: "",
    language: "",
    numberOfPages: "",
    description: "",
    cost: "",
    imageUrl: "",
    categoryId: 1, // default category
  });

  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const editId = params.get("edit");

  // Fetch book details if editing
  useEffect(() => {
    const fetchBook = async () => {
  if (!editId) return;
  try {
    const token = localStorage.getItem("adminToken");
    const res = await axios.get(`https://localhost:7093/api/Book/all`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    const allBooks = res.data;
    const foundBook = allBooks.find((book) => book.bookId == editId);

    if (!foundBook) {
      alert("❌ Book not found");
      return;
    }

    setForm({
      id: foundBook.bookId,
      title: foundBook.title || "",
      author: typeof foundBook.author === "object" ? foundBook.author.name : foundBook.author,
      isbn: foundBook.isbn || "",
      publisher: typeof foundBook.publisher === "object" ? foundBook.publisher.name : foundBook.publisher,
      publicationDate: foundBook.publicationDate?.slice(0, 10) || "",
      edition: foundBook.edition || "",
      language: foundBook.language || "",
      numberOfPages: foundBook.numberOfPages || "",
      description: foundBook.description || "",
      cost: foundBook.cost || "",
      imageUrl: foundBook.imageUrl || "",
      categoryId: foundBook.categoryId || 1,
    });
  } catch (err) {
    console.error(err);
    alert("❌ Failed to fetch book details");
  }
};

    fetchBook();
  }, [editId]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("adminToken");

      if (editId) {
        await axios.put(
          `https://localhost:7093/api/Book/update/${editId}`,
          form,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        alert("✅ Book updated successfully!");
      } else {
        await axios.post(
          "https://localhost:7093/api/Book/add",
          form,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        alert("✅ Book added successfully!");
      }

      navigate("/adminpanel");
    } catch (err) {
      console.error(err);
      alert(err.response?.data || "❌ Failed to submit");
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">{editId ? "✏️ Edit Book" : "➕ Add Book"}</h2>
      <form onSubmit={handleSubmit}>
        {Object.keys(form)
          .filter((key) => key !== "id" && key !== "categoryId")
          .map((key) => (
            <div key={key} className="mb-3">
              <label className="form-label">{key}</label>
              <input
                type={key === "cost" || key === "numberOfPages" ? "number" : "text"}
                name={key}
                className="form-control"
                value={form[key]}
                onChange={handleChange}
                required
              />
            </div>
          ))}

        <button type="submit" className="btn btn-success">
          {editId ? "Update Book" : "Add Book"}
        </button>
      </form>
    </div>
  );
};

export default AddBook;