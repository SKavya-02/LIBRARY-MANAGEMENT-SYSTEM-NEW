import React, { useState } from 'react';
import LoginPage from './LoginPage';
import AdminLoginPage from './AdminLoginPage';

const HomePage = () => {
  const [showAdminLogin, setShowAdminLogin] = useState(false);

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Welcome to LibroVault 📚</h2>

      {showAdminLogin ? (
        <>
          <AdminLoginPage />
          <p className="text-center mt-3">
            Not an admin? <span className="text-primary" style={{ cursor: 'pointer' }} onClick={() => setShowAdminLogin(false)}>Login as User</span>
          </p>
        </>
      ) : (
        <>
          <LoginPage />
          <p className="text-center mt-3">
            Are you an Admin? <span className="text-danger" style={{ cursor: 'pointer' }} onClick={() => setShowAdminLogin(true)}>Login here</span>
          </p>
        </>
      )}
    </div>
  );
};

export default HomePage;
