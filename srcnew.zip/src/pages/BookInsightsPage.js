import React, { useEffect, useState } from "react";
import axios from "axios";
import './BookInsights.css';

const BookInsights = () => {
  const [borrowHistory, setBorrowHistory] = useState([]);
  const [reserveHistory, setReserveHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("adminToken"); // adjust to your login

        const borrowRes = await axios.get("https://localhost:7093/api/Borrow/all", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const reserveRes = await axios.get("https://localhost:7093/api/Reservation/all", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        // ✅ update state with data
        setBorrowHistory(borrowRes.data || []);
        setReserveHistory(reserveRes.data || []);

      } catch (err) {
        console.error("Error fetching insights:", err.response?.data || err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <p>Loading insights...</p>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>📊 Book Insights</h2>

      {/* Borrow History */}
      <h3>Borrow History</h3>
      <table border="1" cellPadding="10" style={{ width: "100%", marginBottom: "20px" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Book ID</th>
            <th>Borrowed Date</th>
            <th>Return Date</th>
            <th>Returned?</th>
            <th>Lost?</th>
            <th>Fine</th>
          </tr>
        </thead>
        <tbody>
          {borrowHistory.length > 0 ? (
            borrowHistory.map((entry) => (
              <tr key={entry.borrowId}>
                <td>{entry.borrowId}</td>
                <td>{entry.userId}</td>
                <td>{entry.bookId}</td>
                <td>{new Date(entry.borrowedDate).toLocaleDateString()}</td>
                <td>{entry.returnDate ? new Date(entry.returnDate).toLocaleDateString() : "Not Returned"}</td>
                <td>{entry.isReturned ? "✅" : "❌"}</td>
                <td>{entry.isLost ? "⚠️ Lost" : "No"}</td>
                <td>₹{entry.fineAmount}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="8" style={{ textAlign: "center" }}>
                No borrow history available
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Reservation History */}
      <h3>Reservation History</h3>
      <table border="1" cellPadding="10" style={{ width: "100%" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Book ID</th>
            <th>Reservation Date</th>
            <th>Active?</th>
          </tr>
        </thead>
        <tbody>
          {reserveHistory.length > 0 ? (
            reserveHistory.map((entry) => (
              <tr key={entry.id}>
                <td>{entry.id}</td>
                <td>{entry.userId}</td>
                <td>{entry.bookId}</td>
                <td>{new Date(entry.reservationDate).toLocaleDateString()}</td>
                <td>{entry.isActive ? "✅ Active" : "❌ Cancelled"}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" style={{ textAlign: "center" }}>
                No reservation history available
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default BookInsights;
