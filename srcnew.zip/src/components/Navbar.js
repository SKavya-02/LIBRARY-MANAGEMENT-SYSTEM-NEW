// src/components/Navbar.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import './Navbar.css';


const Navbar = () => {
  const userToken = localStorage.getItem('userToken');
  const adminToken = localStorage.getItem('adminToken');
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const handleLogout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('adminToken');
    navigate('/');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4">
      <Link className="navbar-brand" to="/dashboard">📚 LibroVault</Link>
      <div className="collapse navbar-collapse">
        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
          {userToken && (
            <>
              
              <li className="nav-item">
  <a className="nav-link" href="/review">
    
  </a>
</li>

            </>
          )}
          {adminToken && (
            <>
              
            </>
          )}
        </ul>

        {(userToken || adminToken) && (
          <div className="dropdown ms-auto">
            <FaUserCircle
              size={30}
              className="text-white"
              onClick={toggleDropdown}
              style={{ cursor: 'pointer' }}
            />
            {dropdownOpen && (
              <div className="dropdown-menu dropdown-menu-end show mt-2" style={{ right: 0 }}>
                <Link className="dropdown-item" to="/profile">Edit Profile ✏️</Link>
                {userToken && (
                  <>
                    
                  </>
                )}
                {adminToken && (
                  <>
                    <Link className="dropdown-item" to="/book-insights">Book Insights 📊</Link>
                  </>
                )}
                <button className="dropdown-item text-danger" onClick={handleLogout}>Logout 🚪</button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
