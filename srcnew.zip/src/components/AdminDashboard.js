// src/components/AdminDashboard.js
import React from "react";
import { useNavigate } from "react-router-dom";

const AdminDashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    navigate("/admin/login");
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">📚 Admin Dashboard</h2>

      <div className="d-flex justify-content-center gap-3">
        <button
          className="btn btn-success"
          onClick={() => navigate("/admin/add-book")}
        >
          ➕ Add Book
        </button>
        <button
          className="btn btn-primary"
          onClick={() => navigate("/admin/manage-books")}
        >
          📖 Manage Books
        </button>
        <button
          className="btn btn-warning"
          onClick={() => navigate("/admin/users")}
        >
          👥 Manage Users
        </button>
        <button className="btn btn-danger" onClick={handleLogout}>
          🚪 Logout
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard;
